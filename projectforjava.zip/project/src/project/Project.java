package project;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.JFrame;

/**
 *
 * @author alanoud
 */
public class Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SplashScreen1 f=new SplashScreen1();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
        new Login().setVisible(false);
        
         




// TODO code application logic here
    }
    
}
